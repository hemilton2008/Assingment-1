# CSA02-1913260131-Assignment1

| Item | Details |
|---|---|
| Name | Hemilton S |
| Register number | 1913260131 |
| Course | CSA02 (Individual assignment, submission date 27-10-2026) |
| Scenario | Grama Jyothi Rural Electricity Co-operative - billing program in C |
| Compiler | gcc 13.3.0 (write the version of YOUR compiler here: `gcc --version`) |
| Standard compile command | `gcc -Wall -Wextra -o <name> <file>.c` (add `-lm` when `math.h` functions are used) |

All money is stored as integer **paise**. Tariff: first 100 units free, 101-200 at Rs 2.25, above 200 at Rs 4.50, fixed charge Rs 50.

## How to build and run each task

| Folder | Compile | Run | Result |
|---|---|---|---|
| Task01 | `gcc -Wall -Wextra -o task01 task01.c` | `./task01` | Data items listed; integer readings need 2 bytes and compare about 16x faster than text readings |
| Task02 | `gcc -Wall -Wextra -o task02_complete task02_complete.c` ; `gcc -o task02_types task02_types.c -lm` ; `gcc -o task02_alt task02_alt.c -lm` | `./task02_complete` etc. | Roll-over gives 256 units; float total wrong by Rs 14.94 for 4000 bills, long paise exact |
| Task03 | `gcc -Wall -Wextra -o task03_complete task03_complete.c` | `./task03_complete` | Output matches the expected output; RATE2_PAISE=230 changes all bills consistently |
| Task04 | `gcc -Wall -Wextra -o task04 task04.c` ; `gcc -O2 -o task04_inline task04_inline.c` | `./task04` ; `./task04_inline` | SQUARE and MAX pitfalls shown and fixed; `gcc -E task04.c` shows the expansion |
| Task05 | `gcc -Wall -Wextra -o bill billing.c main.c` ; add `-DDEBUG` for debug mode | `./bill` | Same bills; debug build prints intermediate values |
| Task06 | `gcc -Wall -Wextra -o task06 task06.c ../Task05/billing.c` | `./task06 < input.txt` | Invalid input detected from the scanf return value |
| Task07 | `gcc -Wall -Wextra -o task07 task07.c -lm` ; `gcc -o task07_alt task07_alt.c -lm` | `./task07` ; `./task07_alt` | Conversion surprises shown; float totals drift, paise do not |
| Task08 | `gcc -E billing9.c -o billing9.i` ; `gcc -S billing9.i` ; `gcc -c billing9.s` ; `gcc billing9.o -o billing9_exe` | `./billing9_exe < ../Task09/tests_all.txt` | All four compilation stages shown; `split/` holds the multi-file version |
| Task09 | `gcc -Wall -Wextra -o billing9 billing9.c` | `./billing9 < tests_all.txt` | 8 bills issued, 4 invalid inputs rejected, five-bill hand total Rs 1487.50 matches |
| Task10 | `gcc -Wall -Wextra -o task10 task10.c -lm` | `./task10` | 32-bit totals overflow at taluk and district scale; 64-bit and double-paise totals are exact |
| Task11 | `gcc -Wall -Wextra -o task11 task11.c` | `./task11 tariff.cfg` | Tariff read from a file; revision needs no recompilation |
| Task12 | `gcc -Wall -Wextra -O2 -o task12 task12.c` | `./task12 tariff12.cfg 800000` | Smart-meter design: 64-bit counters, run-time tariff, peak-hour surcharge, 5 of 5 tests pass |

## Notes
- Sample outputs (`output*.txt`) are included next to each program. Replace/add your own screenshots in `screenshots/` and in each task folder.
- On Windows (MinGW) `long` is 32 bits, so Task02 and Task10 print different sizes; the programs use `long long` / `int64_t` wherever district totals are needed.
