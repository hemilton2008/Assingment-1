/* Task 12 - smart meters: 15-minute readings in Wh, time-of-day tariff, tariff read at run time */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#define SLOTS_PER_DAY      96            /* 24 h x 4 */
#define DAYS_PER_MONTH     30
#define SLOTS_PER_MONTH    (SLOTS_PER_DAY * DAYS_PER_MONTH)   /* 2880 */
#define SLOTS_PER_YEAR     (SLOTS_PER_DAY * 365)              /* 35040 */
#define MAX_DEMAND_W       15000u        /* assumption: largest connected load 15 kW */

typedef struct {
    long slab1, slab2, rate1, rate2, rate3, fixed;   /* paise, units */
    long peak_pct, peak_start, peak_end;             /* percent, hours */
} tariff_t;

typedef struct { uint64_t total_wh, peak_wh; } usage_t;

typedef struct { uint64_t units; int64_t energy, surcharge, fixed, total; } bill_t;

/* ---------- run-time tariff ---------- */
static int load_tariff(const char *path, tariff_t *t)
{
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    char key[64]; long v; int n = 0;
    while (fscanf(fp, "%63s %ld", key, &v) == 2) {
        if      (!strcmp(key, "SLAB1_UNITS"))        { t->slab1 = v; n++; }
        else if (!strcmp(key, "SLAB2_UNITS"))        { t->slab2 = v; n++; }
        else if (!strcmp(key, "RATE1_PAISE"))        { t->rate1 = v; n++; }
        else if (!strcmp(key, "RATE2_PAISE"))        { t->rate2 = v; n++; }
        else if (!strcmp(key, "RATE3_PAISE"))        { t->rate3 = v; n++; }
        else if (!strcmp(key, "FIXED_CHARGE_PAISE")) { t->fixed = v; n++; }
        else if (!strcmp(key, "PEAK_PCT"))           { t->peak_pct = v; n++; }
        else if (!strcmp(key, "PEAK_START_HOUR"))    { t->peak_start = v; n++; }
        else if (!strcmp(key, "PEAK_END_HOUR"))      { t->peak_end = v; n++; }
    }
    fclose(fp);
    return n;
}
static int tariff_ok(const tariff_t *t)
{
    return t->slab1 >= 0 && t->slab1 < t->slab2 && t->rate1 >= 0 && t->rate2 >= 0 && t->rate3 >= 0 &&
           t->fixed >= 0 && t->peak_pct >= 0 && t->peak_pct <= 100 &&
           t->peak_start >= 0 && t->peak_start < t->peak_end && t->peak_end <= 24;
}
static int is_peak_slot(const tariff_t *t, int slot_of_day)
{
    int hour = slot_of_day / 4;
    return hour >= t->peak_start && hour < t->peak_end;
}

/* ---------- billing ---------- */
static int64_t energy_charge(const tariff_t *t, uint64_t units)
{
    int64_t p = 0; uint64_t rest = units;
    if (rest > (uint64_t)t->slab2) { p += (int64_t)(rest - t->slab2) * t->rate3; rest = t->slab2; }
    if (rest > (uint64_t)t->slab1) { p += (int64_t)(rest - t->slab1) * t->rate2; rest = t->slab1; }
    return p + (int64_t)rest * t->rate1;
}
static bill_t make_bill(const tariff_t *t, usage_t u)
{
    bill_t b;
    b.units  = u.total_wh / 1000;                      /* whole kWh, fraction ignored (assumption) */
    b.energy = energy_charge(t, b.units);
    b.fixed  = t->fixed;
    /* surcharge = peak_pct % of the energy charge, in proportion to the peak share of the energy,
       rounded half-up using integers only */
    if (u.total_wh == 0) b.surcharge = 0;
    else {
        uint64_t num = (uint64_t)b.energy * u.peak_wh * (uint64_t)t->peak_pct;
        uint64_t den = 100ull * u.total_wh;
        b.surcharge = (int64_t)((num + den / 2) / den);
    }
    b.total = b.fixed + b.energy + b.surcharge;
    return b;
}

static usage_t constant_usage(const tariff_t *t, unsigned off_wh, unsigned peak_wh)
{
    usage_t u = {0, 0};
    for (int d = 0; d < DAYS_PER_MONTH; d++)
        for (int s = 0; s < SLOTS_PER_DAY; s++) {
            unsigned w = is_peak_slot(t, s) ? peak_wh : off_wh;
            u.total_wh += w; if (is_peak_slot(t, s)) u.peak_wh += w;
        }
    return u;
}

static void rs(const char *label, int64_t p) { printf("%s Rs %lld.%02lld", label, (long long)(p / 100), (long long)(p % 100)); }

int main(int argc, char **argv)
{
    const char *cfg = argc > 1 ? argv[1] : "tariff12.cfg";
    tariff_t t = {0};
    int n = load_tariff(cfg, &t);
    if (n != 9 || !tariff_ok(&t)) { printf("tariff file '%s' missing or invalid (keys read: %d)\n", cfg, n); return 1; }
    printf("Tariff loaded from %s: slabs %ld/%ld units, rates %ld/%ld/%ld paise, fixed %ld paise, peak +%ld%% %02ld:00-%02ld:00\n\n",
           cfg, t.slab1, t.slab2, t.rate1, t.rate2, t.rate3, t.fixed, t.peak_pct, t.peak_start, t.peak_end);

    /* ---- B. largest values that can now occur ---- */
    uint64_t max_wh_slot   = (uint64_t)MAX_DEMAND_W / 4;                      /* W x 0.25 h */
    uint64_t wh_house_year = max_wh_slot * SLOTS_PER_YEAR;
    uint64_t wh_house_mon  = max_wh_slot * SLOTS_PER_MONTH;
    uint64_t rd_dist_year  = (uint64_t)800000 * SLOTS_PER_YEAR;
    uint64_t wh_dist_year  = wh_house_year * 800000;
    usage_t worst = {wh_house_mon, wh_house_mon};              /* month at full load, all in peak window */
    bill_t wb = make_bill(&t, worst);
    uint64_t paise_dist_year = (uint64_t)wb.total * 12 * 800000;
    printf("%-44s %22s  %-6s %-6s %-6s %-6s\n", "Largest value", "value", "u16", "i32", "u32", "u64");
#define ROW(name, v) printf("%-44s %22llu  %-6s %-6s %-6s %-6s\n", name, (unsigned long long)(v), \
        (v) <= 65535ull ? "fits" : "NO", (v) <= 2147483647ull ? "fits" : "NO", (v) <= 4294967295ull ? "fits" : "NO", "fits")
    ROW("Wh in one 15-min reading (15 kW)", max_wh_slot);
    ROW("readings per house per year", (uint64_t)SLOTS_PER_YEAR);
    ROW("Wh per house per month (15 kW)", wh_house_mon);
    ROW("Wh per house per year (15 kW)", wh_house_year);
    ROW("paise: worst monthly bill of one house", (uint64_t)wb.total);
    ROW("readings per district per year", rd_dist_year);
    ROW("Wh per district per year", wh_dist_year);
    ROW("paise per district per year (worst case)", paise_dist_year);
    printf("32-bit counter of district readings per year would show %u instead of %llu\n\n",
           (unsigned)(uint32_t)rd_dist_year, (unsigned long long)rd_dist_year);

    /* ---- C/D. correctness tests with hand-calculated answers ---- */
    struct { const char *name; unsigned off, peak; int64_t expect; } tc[] = {
        {"uniform 125 Wh/slot (360 kWh, 1/6 in peak)", 125, 125, 102650},
        {"no use in peak window (360 kWh off-peak)",   150,   0,  99500},
        {"all use in peak window",                       0,  75, 5000 + 0 + 0},
        {"zero consumption",                             0,   0,   5000},
    };
    /* case 3: peak only 75 Wh x 480 slots = 36,000 Wh = 36 units -> free slab -> energy 0, surcharge 0 */
    printf("%-46s %12s %12s %s\n", "Test", "expected", "actual", "status");
    int pass = 0;
    for (int i = 0; i < 4; i++) {
        bill_t b = make_bill(&t, constant_usage(&t, tc[i].off, tc[i].peak));
        printf("%-46s ", tc[i].name);
        printf("Rs %7lld.%02lld ", (long long)(tc[i].expect / 100), (long long)(tc[i].expect % 100));
        printf("Rs %7lld.%02lld ", (long long)(b.total / 100), (long long)(b.total % 100));
        printf("%s\n", b.total == tc[i].expect ? "PASS" : "FAIL"); pass += b.total == tc[i].expect;
    }
    {   /* case 5: peak-only use above free slab: 360 kWh all in 4 peak hours -> 750 Wh/slot x 480 */
        usage_t u = constant_usage(&t, 0, 750);
        bill_t b = make_bill(&t, u);
        int64_t expect = 5000 + 94500 + 18900;       /* 360 units: 22500+72000 energy; +20% = 18900 */
        printf("%-46s Rs %7lld.%02lld Rs %7lld.%02lld %s\n", "all 360 kWh inside the peak window",
               (long long)(expect / 100), (long long)(expect % 100), (long long)(b.total / 100), (long long)(b.total % 100),
               b.total == expect ? "PASS" : "FAIL");
        pass += b.total == expect;
    }
    printf("%d of 5 tests passed\n\n", pass);

    /* ---- scale test: one month for a district ---- */
    long houses = argc > 2 ? atol(argv[2]) : 800000;
    uint64_t readings = 0, wh_all = 0; int64_t grand = 0;
    clock_t t0 = clock();
    for (long h = 0; h < houses; h++) {
        uint32_t x = 2463534242u ^ (uint32_t)(h * 2654435761u);
        usage_t u = {0, 0};
        for (int d = 0; d < DAYS_PER_MONTH; d++)
            for (int s = 0; s < SLOTS_PER_DAY; s++) {
                x ^= x << 13; x ^= x >> 17; x ^= x << 5;
                unsigned w = 20 + (x % 120);
                int pk = is_peak_slot(&t, s);
                if (pk) w += 60;
                u.total_wh += w; if (pk) u.peak_wh += w;
                readings++;
            }
        bill_t b = make_bill(&t, u);
        grand += b.total; wh_all += u.total_wh;
    }
    double sec = (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("Month for %ld houses: %llu readings, %llu Wh, total bills ", houses, (unsigned long long)readings, (unsigned long long)wh_all);
    rs("", grand);
    printf("\nprocessing time %.2f s (%.1f ns per reading); readings stored as uint16: %.1f GB\n",
           sec, sec / readings * 1e9, readings * 2.0 / 1e9);
    return 0;
}
