/* Task 12 - evidence: the ORIGINAL types (16-bit meter_t, int totals) applied to smart-meter data */
#include <stdio.h>
#include <stdint.h>
typedef unsigned short meter_t;           /* original 16-bit type */
int main(void)
{
    meter_t month_wh16 = 0;               /* monthly Wh kept in the original 16-bit type */
    unsigned int month_wh32 = 0;
    for (int i = 0; i < 2880; i++) { month_wh16 += 125; month_wh32 += 125; }
    printf("true monthly energy      : %u Wh = %u kWh\n", month_wh32, month_wh32 / 1000);
    printf("16-bit meter_t result    : %u Wh = %u kWh   <- wrong (wrapped modulo 65536)\n", (unsigned)month_wh16, (unsigned)month_wh16 / 1000);
    uint32_t readings32 = 0; uint64_t readings64 = 0;
    for (long h = 0; h < 800000; h += 1) { readings32 += 35040u; readings64 += 35040u; }
    printf("district readings/year   : 32-bit counter %u, 64-bit counter %llu\n", (unsigned)readings32, (unsigned long long)readings64);
    int32_t paise32 = 0; int64_t paise64 = 0;
    for (long h = 0; h < 800000; h++) { paise64 += 5756000 * 12; paise32 = (int32_t)((uint32_t)paise32 + (uint32_t)(5756000 * 12)); }
    printf("district yearly paise    : 32-bit total %d, 64-bit total %lld\n", (int)paise32, (long long)paise64);
    return 0;
}
