Put one terminal screenshot per task here (and copy the same file into each TaskNN folder):
Task01_output.png ... Task12_output.png
Run every program yourself and take the screenshot from your own terminal.
