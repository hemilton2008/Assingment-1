/* Task 06 - read and print data correctly (scanf with validation) */
#include <stdio.h>
#include "../Task05/tariff.h"

static void skip_line(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

int main(void)
{
    unsigned int house;
    int prev, curr;
    int line = 0;
    printf("Enter: household previous current   (Ctrl+D to stop)\n");
    for (;;) {
        int n = scanf("%u %d %d", &house, &prev, &curr);
        if (n == EOF) break;
        line++;
        if (n != 3) {
            printf("Line %d: invalid input (scanf returned %d) - skipped\n", line, n);
            skip_line();
            continue;
        }
        skip_line();
        if (prev < 0 || prev > 65535 || curr < 0 || curr > 65535) {
            printf("Line %d: reading out of range 0..65535 - skipped\n", line);
            continue;
        }
        unsigned int u = consumption((meter_t)prev, (meter_t)curr);
        long p = compute_bill(u);
        printf("House %u: %u units, bill Rs %ld.%02ld\n", house, u, p / 100, p % 100);
    }
    return 0;
}
