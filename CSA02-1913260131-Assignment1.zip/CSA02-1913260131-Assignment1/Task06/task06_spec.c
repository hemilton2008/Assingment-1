/* Task 06 - what a wrong format specifier does */
#include <stdio.h>
int main(void)
{
    long big = 5000000000L;
    int  i = 42;
    double d = 162.5;
    printf("correct  %%ld : %ld\n", big);
    printf("wrong    %%d  : %d   (long printed with %%d)\n", (int)big == 0 ? 0 : (int)big);
    printf("wrong    %%f for int  : ");
    printf("%f\n", (double)i);
    printf("correct  %%lf/%%f : %f\n", d);
    printf("correct  %%c %%s %%u : %c %s %u\n", 'R', "paise", 16250u);
    printf("rupees and paise from 16250 paise: Rs %ld.%02ld\n", 16250L / 100, 16250L % 100);
    return 0;
}
