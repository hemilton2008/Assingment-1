#include <stdio.h>
int main(void)
{
    long big = 5000000000L;
    int i = 42;
    printf("%d\n", big);     /* wrong: %d with long  */
    printf("%f\n", i);       /* wrong: %f with int   */
    return 0;
}
