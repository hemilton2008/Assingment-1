/* Task 06 alternative: fgets + strtol */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include "../Task05/tariff.h"

static int parse_reading(const char *s, char **end, long *out)
{
    errno = 0;
    long v = strtol(s, end, 10);
    if (*end == s || errno != 0 || v < 0 || v > 65535) return 0;
    *out = v;
    return 1;
}

int main(void)
{
    char line[64];
    int ln = 0;
    while (fgets(line, sizeof line, stdin)) {
        ln++;
        char *p = line, *e;
        long house, prev, curr;
        house = strtol(p, &e, 10);
        if (e == p) { printf("Line %d: invalid input - skipped\n", ln); continue; }
        p = e;
        if (!parse_reading(p, &e, &prev)) { printf("Line %d: invalid previous reading - skipped\n", ln); continue; }
        p = e;
        if (!parse_reading(p, &e, &curr)) { printf("Line %d: invalid current reading - skipped\n", ln); continue; }
        unsigned int u = consumption((meter_t)prev, (meter_t)curr);
        long b = compute_bill(u);
        printf("House %ld: %u units, bill Rs %ld.%02ld\n", house, u, b / 100, b % 100);
    }
    return 0;
}
