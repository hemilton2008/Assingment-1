/* Task 02 - sizes, ranges, float money problem, 16-bit rollover */
#include <stdio.h>
#include <limits.h>
#include <float.h>
#include <math.h>

int main(void)
{
    printf("%-20s %5s  %s\n", "type", "bytes", "range");
    printf("%-20s %5zu  %d to %d\n", "char", sizeof(char), CHAR_MIN, CHAR_MAX);
    printf("%-20s %5zu  0 to %u\n", "unsigned short", sizeof(unsigned short), (unsigned)USHRT_MAX);
    printf("%-20s %5zu  %d to %d\n", "short", sizeof(short), SHRT_MIN, SHRT_MAX);
    printf("%-20s %5zu  %d to %d\n", "int", sizeof(int), INT_MIN, INT_MAX);
    printf("%-20s %5zu  0 to %u\n", "unsigned int", sizeof(unsigned), UINT_MAX);
    printf("%-20s %5zu  %ld to %ld\n", "long", sizeof(long), LONG_MIN, LONG_MAX);
    printf("%-20s %5zu  %lld to %lld\n", "long long", sizeof(long long), LLONG_MIN, LLONG_MAX);
    printf("%-20s %5zu  max %e, ~%d decimal digits\n", "float", sizeof(float), FLT_MAX, FLT_DIG);
    printf("%-20s %5zu  max %e, ~%d decimal digits\n", "double", sizeof(double), DBL_MAX, DBL_DIG);

    /* float money: add Rs 0.10 (10 paise) 4000 times */
    float f = 0.0f; double d = 0.0; long p = 0;
    for (int i = 0; i < 4000; i++) { f += 0.10f; d += 0.10; p += 10; }
    printf("\n4000 bills of Rs 0.10 (exact total Rs 400.00):\n");
    printf("  float  rupees : %.6f\n", f);
    printf("  double rupees : %.10f\n", d);
    printf("  long   paise  : %ld.%02ld\n", p / 100, p % 100);

    /* a larger-value example: Rs 162.37 * 4000 bills in float */
    float f2 = 0.0f; long p2 = 0;
    for (int i = 0; i < 4000; i++) { f2 += 162.37f; p2 += 16237; }
    printf("4000 bills of Rs 162.37 (exact Rs 649480.00):\n");
    printf("  float  rupees : %.4f\n", f2);
    printf("  long   paise  : %ld.%02ld\n", p2 / 100, p2 % 100);

    /* 16-bit rollover */
    unsigned short r = 65535;
    printf("\nregister 65535 + 1 = %u (wraps to 0)\n", (unsigned short)(r + 1));
    int naive = 120 - 65400;
    printf("naive 120 - 65400 (int) = %d ; as 16-bit unsigned = %u\n", naive, (unsigned short)naive);
    return 0;
}
