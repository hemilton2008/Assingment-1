#include <stdio.h>
#include <limits.h>
/* The meter register is a 16-bit counter: after 65535 it rolls over to 0. */
typedef unsigned short meter_t;
unsigned int consumption(meter_t previous, meter_t current)
{
    /* TODO 1 solved: the subtraction is done in int (integer promotion);
       converting the result back to meter_t reduces it modulo 65536, which
       is exactly the roll-over arithmetic. No if-else is needed. */
    return (meter_t)(current - previous);
}
int main(void)
{
    printf("sizeof(meter_t) = %zu bytes, maximum reading = %u\n",
           sizeof(meter_t), (unsigned)USHRT_MAX);
    printf("Consumption: %u units\n", consumption(1200, 1530));
    printf("Consumption: %u units\n", consumption(65400, 120)); /* rolled over */
    return 0;
}
