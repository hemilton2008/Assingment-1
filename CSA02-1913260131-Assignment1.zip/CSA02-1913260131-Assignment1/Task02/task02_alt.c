/* Task 02 alternative: money as double rupees vs long paise, error growth */
#include <stdio.h>
#include <math.h>
int main(void)
{
    long ns[] = {4000, 60000, 800000};
    printf("%8s %18s %18s %14s\n", "n bills", "double total (Rs)", "exact (Rs)", "abs error");
    for (int k = 0; k < 3; k++) {
        double d = 0.0; long p = 0;
        for (long i = 0; i < ns[k]; i++) { d += 162.37; p += 16237; }
        double exact = p / 100.0;
        printf("%8ld %18.6f %18.2f %14.3e\n", ns[k], d, exact, fabs(d - exact));
    }
    printf("sizeof(double)=%zu sizeof(long)=%zu\n", sizeof(double), sizeof(long));
    return 0;
}
