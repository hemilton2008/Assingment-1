/* Task 10 - expected vs observed: totals at village / taluk / district scale */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>
#include <float.h>
#include <math.h>

#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE2_PAISE 225
#define RATE3_PAISE 450
#define FIXED_CHARGE_PAISE 5000L

static long bill_paise(unsigned units)
{
    long p = FIXED_CHARGE_PAISE;
    if (units > SLAB2_UNITS) { p += (long)(units - SLAB2_UNITS) * RATE3_PAISE; units = SLAB2_UNITS; }
    if (units > SLAB1_UNITS) p += (long)(units - SLAB1_UNITS) * RATE2_PAISE;
    return p;
}

int main(void)
{
    long ns[] = {4000, 60000, 800000};
    printf("sizes here: int %zu, long %zu, long long %zu, float %zu, double %zu\n\n",
           sizeof(int), sizeof(long), sizeof(long long), sizeof(float), sizeof(double));
    printf("%8s | %16s | %16s %12s | %16s %12s\n", "bills", "paise total (Rs)", "float total (Rs)", "diff (Rs)", "double total(Rs)", "diff (Rs)");
    for (int k = 0; k < 3; k++) {
        srand(2026);
        long long exact = 0; float f = 0; double d = 0;
        for (long i = 0; i < ns[k]; i++) {
            unsigned units = (unsigned)(rand() % 601);        /* 0..600 units */
            long p = bill_paise(units);
            exact += p;
            f += p / 100.0f;
            d += p / 100.0;
        }
        printf("%8ld | %13lld.%02lld | %16.2f %12.2f | %16.2f %12.6f\n", ns[k], exact / 100, exact % 100,
               f, fabs((double)f - exact / 100.0), d, fabs(d - exact / 100.0));
    }

    /* overflow of integer accumulators (unsigned used so the wrap is well defined) */
    printf("\n%8s | %-22s | %-22s | %-22s\n", "bills", "32-bit total (paise)", "64-bit total (paise)", "32-bit overflowed?");
    for (int k = 0; k < 3; k++) {
        srand(2026);
        int64_t t64 = 0; uint32_t t32 = 0;
        for (long i = 0; i < ns[k]; i++) {
            long p = bill_paise((unsigned)(rand() % 601));
            t64 += p; t32 += (uint32_t)p;
        }
        printf("%8ld | %-22u | %-22lld | %-22s\n", ns[k], (unsigned)t32, (long long)t64,
               t64 > (int64_t)INT_MAX ? "YES (max 2147483647)" : "no");
    }
    /* how many bills until a signed 32-bit paise total overflows (average ~Rs 330) */
    printf("\nINT_MAX paise = Rs %d.%02d -> overflows after about %ld bills of Rs 330\n",
           INT_MAX / 100, INT_MAX % 100, (long)(INT_MAX / 33000L));

    /* C-standard minimums versus this system */
    printf("\n%-12s %-14s %s\n", "type", "standard min", "this system");
    printf("%-12s %-14s %d bits\n", "char", "8 bits", CHAR_BIT);
    printf("%-12s %-14s %zu bits\n", "short", "16 bits", sizeof(short) * CHAR_BIT);
    printf("%-12s %-14s %zu bits\n", "int", "16 bits", sizeof(int) * CHAR_BIT);
    printf("%-12s %-14s %zu bits\n", "long", "32 bits", sizeof(long) * CHAR_BIT);
    printf("%-12s %-14s %zu bits\n", "long long", "64 bits", sizeof(long long) * CHAR_BIT);
    printf("%-12s %-14s %d digits\n", "float", "6 digits", FLT_DIG);
    printf("%-12s %-14s %d digits\n", "double", "10 digits", DBL_DIG);
    return 0;
}
