/* Task 10 alternative: district total accumulated in double instead of long long */
#include <stdio.h>
#include <time.h>
int main(void)
{
    double two53 = 9007199254740992.0;           /* 2^53 */
    double x = two53;
    printf("2^53 = %.0f paise (= Rs %.0f)\n", two53, two53 / 100);
    printf("2^53 + 1 in double = %.0f  (the extra paisa is lost)\n", x + 1.0);
    printf("2^53 + 2 in double = %.0f\n", x + 2.0);
    printf("LLONG_MAX = 9223372036854775807 paise = Rs 92233720368547758.07\n");
    /* 800000 bills in double paise are still exact */
    double d = 0; long long l = 0;
    for (long i = 0; i < 800000; i++) { long p = 5000 + (i % 1000) * 7; d += p; l += p; }
    printf("800000 bills: double %.0f, long long %lld, equal: %s\n", d, l, d == (double)l ? "yes" : "no");
    const long N = 400000000L; volatile double vd = 0; volatile long long vl = 0;
    clock_t t0 = clock(); for (long i = 0; i < N; i++) vd = vd + 1.0; double td = (double)(clock()-t0)/CLOCKS_PER_SEC;
    t0 = clock(); for (long i = 0; i < N; i++) vl = vl + 1; double tl = (double)(clock()-t0)/CLOCKS_PER_SEC;
    printf("%ld additions: double %.3f s, long long %.3f s; space %zu and %zu bytes\n", N, td, tl, sizeof(double), sizeof(long long));
    return 0;
}
