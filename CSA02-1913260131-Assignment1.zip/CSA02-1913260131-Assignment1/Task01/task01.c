/* Task 01 - data items of the billing problem + text vs integer readings */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define N 5000000L
#define D 5            /* digits in a 16-bit reading: 00000..65535 */

int main(void)
{
    /* ---- Part A: data items and their storage ---- */
    printf("%-22s %-10s %s\n", "Data item", "Kind", "Reason");
    printf("%-22s %-10s %s\n", "household number", "input", "identifier, never negative, up to 800000");
    printf("%-22s %-10s %s\n", "previous/current", "input", "16-bit register 0..65535");
    printf("%-22s %-10s %s\n", "units consumed", "computed", "0..65535, never negative");
    printf("%-22s %-10s %s\n", "slab limits, rates", "constant", "same for every bill in a run");
    printf("%-22s %-10s %s\n", "fixed charge", "constant", "Rs 50 = 5000 paise");
    printf("%-22s %-10s %s\n", "energy charge", "computed", "paise, integer");
    printf("%-22s %-10s %s\n", "total bill", "computed", "fixed + energy, paise");
    printf("%-22s %-10s %s\n", "district total", "computed", "sum of 800000 bills, paise");

    /* ---- Part B: alternative - readings stored as text ---- */
    char (*txt)[D + 1] = malloc(N * (D + 1));
    unsigned short *num = malloc(N * sizeof *num);
    if (!txt || !num) return 1;
    srand(1);
    for (long i = 0; i < N; i++) {
        num[i] = (unsigned short)(rand() % 65536);
        snprintf(txt[i], D + 1, "%05u", (unsigned)num[i]);
    }
    printf("\nspace per reading: integer = %zu bytes, text = %d bytes\n",
           sizeof(unsigned short), D + 1);

    clock_t t0 = clock();
    long gt_int = 0;
    for (long i = 1; i < N; i++) gt_int += (num[i] > num[i - 1]);
    double t_int = (double)(clock() - t0) / CLOCKS_PER_SEC;

    t0 = clock();
    long gt_txt = 0;
    for (long i = 1; i < N; i++) gt_txt += (strcmp(txt[i], txt[i - 1]) > 0);
    double t_cmp = (double)(clock() - t0) / CLOCKS_PER_SEC;

    t0 = clock();
    long gt_conv = 0;
    for (long i = 1; i < N; i++) gt_conv += (atoi(txt[i]) > atoi(txt[i - 1]));
    double t_conv = (double)(clock() - t0) / CLOCKS_PER_SEC;

    printf("compare %ld pairs: integer %.4f s | text strcmp %.4f s | text atoi+compare %.4f s\n",
           N - 1, t_int, t_cmp, t_conv);
    printf("greater-than counts (must agree): %ld %ld %ld\n", gt_int, gt_txt, gt_conv);
    free(txt); free(num);
    return 0;
}
