#include <stdio.h>
int main(void)
{
    printf("%ld\n", compute_bill(10));
    return 0;
}
