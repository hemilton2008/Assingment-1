	.file	"billing9.c"
	.text
	.type	energy_charge, @function
energy_charge:
.LFB0:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	%edi, -20(%rbp)
	movq	$0, -8(%rbp)
	movl	-20(%rbp), %eax
	movl	%eax, -12(%rbp)
	cmpl	$200, -12(%rbp)
	jbe	.L2
	movl	-12(%rbp), %eax
	subl	$200, %eax
	movl	%eax, %eax
	imulq	$450, %rax, %rax
	addq	%rax, -8(%rbp)
	movl	$200, -12(%rbp)
.L2:
	cmpl	$100, -12(%rbp)
	jbe	.L3
	movl	-12(%rbp), %eax
	subl	$100, %eax
	movl	%eax, %eax
	imulq	$225, %rax, %rax
	addq	%rax, -8(%rbp)
	movl	$100, -12(%rbp)
.L3:
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	energy_charge, .-energy_charge
	.type	make_bill, @function
make_bill:
.LFB1:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -40(%rbp)
	movl	%esi, -44(%rbp)
	movl	-44(%rbp), %eax
	movl	%eax, -32(%rbp)
	movl	-44(%rbp), %eax
	movl	%eax, %edi
	call	energy_charge
	movq	%rax, -24(%rbp)
	movq	$5000, -16(%rbp)
	movq	-24(%rbp), %rdx
	movq	-16(%rbp), %rax
	addq	%rdx, %rax
	movq	%rax, -8(%rbp)
	movq	-40(%rbp), %rcx
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	movq	%rax, 16(%rcx)
	movq	%rdx, 24(%rcx)
	movq	-40(%rbp), %rax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	make_bill, .-make_bill
	.type	skip_line, @function
skip_line:
.LFB2:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	nop
.L9:
	call	getchar@PLT
	movl	%eax, -4(%rbp)
	cmpl	$10, -4(%rbp)
	je	.L10
	cmpl	$-1, -4(%rbp)
	jne	.L9
.L10:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	skip_line, .-skip_line
	.section	.rodata
.LC0:
	.string	"Energy(Rs)"
.LC1:
	.string	"Units"
.LC2:
	.string	"Current"
.LC3:
	.string	"Previous"
.LC4:
	.string	"House"
	.align 8
.LC5:
	.string	"%-6s %8s %8s %6s %12s %10s %12s\n"
.LC6:
	.string	"Total(Rs)"
.LC7:
	.string	"Fixed(Rs)"
.LC8:
	.string	"%u %d %d"
	.align 8
.LC9:
	.string	"Bills issued: %d, rejected: %d, grand total: Rs %ld.%02ld\n"
	.align 8
.LC10:
	.string	"line %d: INVALID INPUT (not numbers)\n"
	.align 8
.LC11:
	.string	"line %d: INVALID (reading outside 0..%d)\n"
	.align 8
.LC12:
	.string	"line %d: INVALID (current %d < previous %d without roll-over)\n"
	.align 8
.LC13:
	.string	"%-6u %8d %8d %6u %9ld.%02ld %7ld.%02ld %9ld.%02ld\n"
	.text
	.globl	main
	.type	main, @function
main:
.LFB3:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 3, -24
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movl	$0, -92(%rbp)
	movl	$0, -88(%rbp)
	movl	$0, -84(%rbp)
	movq	$0, -72(%rbp)
	leaq	.LC6(%rip), %rax
	pushq	%rax
	leaq	.LC7(%rip), %rax
	pushq	%rax
	leaq	.LC0(%rip), %r9
	leaq	.LC1(%rip), %r8
	leaq	.LC2(%rip), %rax
	movq	%rax, %rcx
	leaq	.LC3(%rip), %rax
	movq	%rax, %rdx
	leaq	.LC4(%rip), %rax
	movq	%rax, %rsi
	leaq	.LC5(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	addq	$16, %rsp
.L20:
	leaq	-96(%rbp), %rcx
	leaq	-100(%rbp), %rdx
	leaq	-104(%rbp), %rax
	movq	%rax, %rsi
	leaq	.LC8(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	__isoc99_scanf@PLT
	movl	%eax, -80(%rbp)
	cmpl	$-1, -80(%rbp)
	jne	.L12
	movq	-72(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	movq	%rdx, %rsi
	subq	%rax, %rsi
	movq	%rsi, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	leaq	0(,%rax,4), %rdx
	addq	%rdx, %rax
	salq	$2, %rax
	movq	%rcx, %rsi
	subq	%rax, %rsi
	movq	-72(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	movq	%rdx, %rcx
	subq	%rax, %rcx
	movl	-84(%rbp), %edx
	movl	-88(%rbp), %eax
	movq	%rsi, %r8
	movl	%eax, %esi
	leaq	.LC9(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$0, %eax
	movq	-24(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L21
	jmp	.L22
.L12:
	addl	$1, -92(%rbp)
	cmpl	$3, -80(%rbp)
	je	.L14
	movl	-92(%rbp), %eax
	movl	%eax, %esi
	leaq	.LC10(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	call	skip_line
	addl	$1, -84(%rbp)
	jmp	.L19
.L14:
	call	skip_line
	movl	-100(%rbp), %eax
	testl	%eax, %eax
	js	.L16
	movl	-100(%rbp), %eax
	cmpl	$65535, %eax
	jg	.L16
	movl	-96(%rbp), %eax
	testl	%eax, %eax
	js	.L16
	movl	-96(%rbp), %eax
	cmpl	$65535, %eax
	jle	.L17
.L16:
	movl	-92(%rbp), %eax
	movl	$65535, %edx
	movl	%eax, %esi
	leaq	.LC11(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, -84(%rbp)
	jmp	.L19
.L17:
	movl	-96(%rbp), %eax
	movl	%eax, %edx
	movl	-100(%rbp), %eax
	movl	%eax, %ecx
	movl	%edx, %eax
	subl	%ecx, %eax
	movzwl	%ax, %eax
	movl	%eax, -76(%rbp)
	cmpl	$5000, -76(%rbp)
	jbe	.L18
	movl	-100(%rbp), %ecx
	movl	-96(%rbp), %edx
	movl	-92(%rbp), %eax
	movl	%eax, %esi
	leaq	.LC12(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, -84(%rbp)
	jmp	.L19
.L18:
	leaq	-64(%rbp), %rax
	movl	-76(%rbp), %edx
	movl	%edx, %esi
	movq	%rax, %rdi
	call	make_bill
	movq	-40(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	subq	%rax, %rdx
	movq	%rdx, %r8
	movq	%r8, %rax
	salq	$2, %rax
	addq	%r8, %rax
	leaq	0(,%rax,4), %rdx
	addq	%rdx, %rax
	salq	$2, %rax
	subq	%rax, %rcx
	movq	%rcx, %r8
	movq	-40(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	subq	%rax, %rdx
	movq	%rdx, %r10
	movq	-48(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	movq	%rdx, %rdi
	subq	%rax, %rdi
	movq	%rdi, %rax
	salq	$2, %rax
	addq	%rdi, %rax
	leaq	0(,%rax,4), %rdx
	addq	%rdx, %rax
	salq	$2, %rax
	movq	%rcx, %rdi
	subq	%rax, %rdi
	movq	-48(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	subq	%rax, %rdx
	movq	%rdx, %r9
	movq	-56(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	movq	%rdx, %rsi
	subq	%rax, %rsi
	movq	%rsi, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	leaq	0(,%rax,4), %rdx
	addq	%rdx, %rax
	salq	$2, %rax
	movq	%rcx, %rsi
	subq	%rax, %rsi
	movq	-56(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	movq	%rdx, %rbx
	subq	%rax, %rbx
	movl	-64(%rbp), %r11d
	movl	-96(%rbp), %ecx
	movl	-100(%rbp), %edx
	movl	-104(%rbp), %eax
	subq	$8, %rsp
	pushq	%r8
	pushq	%r10
	pushq	%rdi
	pushq	%r9
	pushq	%rsi
	movq	%rbx, %r9
	movl	%r11d, %r8d
	movl	%eax, %esi
	leaq	.LC13(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	addq	$48, %rsp
	movq	-40(%rbp), %rax
	addq	%rax, -72(%rbp)
	addl	$1, -88(%rbp)
.L19:
	jmp	.L20
.L22:
	call	__stack_chk_fail@PLT
.L21:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
