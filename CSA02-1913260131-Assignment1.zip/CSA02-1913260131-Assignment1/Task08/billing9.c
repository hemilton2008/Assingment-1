/* Task 09 - Grama Jyothi billing program (all amounts in paise) */
#include <stdio.h>

/* ---- tariff: the only place where tariff values appear ---- */
#define SLAB1_UNITS         100
#define SLAB2_UNITS         200
#define RATE1_PAISE         0
#define RATE2_PAISE         225
#define RATE3_PAISE         450
#define FIXED_CHARGE_PAISE  5000L
#define MAX_MONTHLY_UNITS   5000u      /* larger values are treated as faulty readings */
#define REG_MAX             65535

typedef unsigned short meter_t;

typedef struct {
    unsigned int units;
    long energy;       /* paise */
    long fixed;        /* paise */
    long total;        /* paise */
} bill_t;

static long energy_charge(unsigned int units)
{
    long paise = 0;
    unsigned int rest = units;
    if (rest > SLAB2_UNITS) { paise += (long)(rest - SLAB2_UNITS) * RATE3_PAISE; rest = SLAB2_UNITS; }
    if (rest > SLAB1_UNITS) { paise += (long)(rest - SLAB1_UNITS) * RATE2_PAISE; rest = SLAB1_UNITS; }
    paise += (long)rest * RATE1_PAISE;
    return paise;
}

static bill_t make_bill(unsigned int units)
{
    bill_t b;
    b.units  = units;
    b.energy = energy_charge(units);
    b.fixed  = FIXED_CHARGE_PAISE;
    b.total  = b.energy + b.fixed;
    return b;
}

static void skip_line(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

int main(void)
{
    unsigned int house;
    int prev, curr, line = 0, ok = 0, bad = 0;
    long grand = 0;

    printf("%-6s %8s %8s %6s %12s %10s %12s\n",
           "House", "Previous", "Current", "Units", "Energy(Rs)", "Fixed(Rs)", "Total(Rs)");
    for (;;) {
        int n = scanf("%u %d %d", &house, &prev, &curr);
        if (n == EOF) break;
        line++;
        if (n != 3) { printf("line %d: INVALID INPUT (not numbers)\n", line); skip_line(); bad++; continue; }
        skip_line();
        if (prev < 0 || prev > REG_MAX || curr < 0 || curr > REG_MAX) {
            printf("line %d: INVALID (reading outside 0..%d)\n", line, REG_MAX); bad++; continue;
        }
        unsigned int units = (meter_t)(curr - prev);     /* handles roll-over */
        if (units > MAX_MONTHLY_UNITS) {
            printf("line %d: INVALID (current %d < previous %d without roll-over)\n", line, curr, prev);
            bad++; continue;
        }
        bill_t b = make_bill(units);
        printf("%-6u %8d %8d %6u %9ld.%02ld %7ld.%02ld %9ld.%02ld\n", house, prev, curr, b.units,
               b.energy / 100, b.energy % 100, b.fixed / 100, b.fixed % 100, b.total / 100, b.total % 100);
        grand += b.total; ok++;
    }
    printf("Bills issued: %d, rejected: %d, grand total: Rs %ld.%02ld\n", ok, bad, grand / 100, grand % 100);
    return 0;
}
