#include <stdio.h>
#include "bill.h"
void print_header(void)
{
    printf("%-6s %8s %8s %6s %12s %10s %12s\n", "House", "Previous", "Current", "Units",
           "Energy(Rs)", "Fixed(Rs)", "Total(Rs)");
}
void print_row(unsigned house, int prev, int curr, bill_t b)
{
    printf("%-6u %8d %8d %6u %9ld.%02ld %7ld.%02ld %9ld.%02ld\n", house, prev, curr, b.units,
           b.energy / 100, b.energy % 100, b.fixed / 100, b.fixed % 100, b.total / 100, b.total % 100);
}
void print_summary(int ok, int bad, long grand)
{
    printf("Bills issued: %d, rejected: %d, grand total: Rs %ld.%02ld\n", ok, bad, grand / 100, grand % 100);
}
