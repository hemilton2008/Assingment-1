#include "bill.h"
static long energy_charge(unsigned int units)
{
    long paise = 0; unsigned int rest = units;
    if (rest > SLAB2_UNITS) { paise += (long)(rest - SLAB2_UNITS) * RATE3_PAISE; rest = SLAB2_UNITS; }
    if (rest > SLAB1_UNITS) { paise += (long)(rest - SLAB1_UNITS) * RATE2_PAISE; rest = SLAB1_UNITS; }
    return paise + (long)rest * RATE1_PAISE;
}
bill_t make_bill(unsigned int units)
{
    bill_t b; b.units = units; b.energy = energy_charge(units);
    b.fixed = FIXED_CHARGE_PAISE; b.total = b.energy + b.fixed; return b;
}
