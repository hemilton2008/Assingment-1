#include <stdio.h>
#include "bill.h"
static void skip_line(void) { int c; while ((c = getchar()) != '\n' && c != EOF) { } }
int read_record(unsigned *house, int *prev, int *curr, unsigned *units, int line)
{
    int n = scanf("%u %d %d", house, prev, curr);
    if (n == EOF) return -1;
    if (n != 3) { printf("line %d: INVALID INPUT (not numbers)\n", line); skip_line(); return 0; }
    skip_line();
    if (*prev < 0 || *prev > REG_MAX || *curr < 0 || *curr > REG_MAX) {
        printf("line %d: INVALID (reading outside 0..%d)\n", line, REG_MAX); return 0; }
    *units = (meter_t)(*curr - *prev);
    if (*units > MAX_MONTHLY_UNITS) {
        printf("line %d: INVALID (current %d < previous %d without roll-over)\n", line, *curr, *prev); return 0; }
    return 1;
}
