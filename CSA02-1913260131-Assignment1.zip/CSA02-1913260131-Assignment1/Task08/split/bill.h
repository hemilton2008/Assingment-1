#ifndef BILL_H
#define BILL_H
#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE1_PAISE 0
#define RATE2_PAISE 225
#define RATE3_PAISE 450
#define FIXED_CHARGE_PAISE 5000L
#define MAX_MONTHLY_UNITS 5000u
#define REG_MAX 65535
typedef unsigned short meter_t;
typedef struct { unsigned int units; long energy, fixed, total; } bill_t;
bill_t make_bill(unsigned int units);                                   /* tariff.c */
int read_record(unsigned *house, int *prev, int *curr, unsigned *units, int line); /* input.c: 1 ok, 0 bad, -1 EOF */
void print_header(void);                                                /* report.c */
void print_row(unsigned house, int prev, int curr, bill_t b);
void print_summary(int ok, int bad, long grand);
#endif
