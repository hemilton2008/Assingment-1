#include "bill.h"
int main(void)
{
    unsigned house, units; int prev, curr, line = 0, ok = 0, bad = 0, r; long grand = 0;
    print_header();
    while ((r = read_record(&house, &prev, &curr, &units, ++line)) != -1) {
        if (r == 0) { bad++; continue; }
        bill_t b = make_bill(units); print_row(house, prev, curr, b); grand += b.total; ok++;
    }
    print_summary(ok, bad, grand);
    return 0;
}
