#include <stdio.h>
long compute_bill(int units);
int main(void)
{
    printf("%ld\n", compute_bill(10));
    return 0;
}
