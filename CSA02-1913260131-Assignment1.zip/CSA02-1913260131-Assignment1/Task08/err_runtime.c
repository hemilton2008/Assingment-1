#include <stdio.h>
int main(void)
{
    int paise = 16250, houses = 0;
    printf("%d\n", paise / houses);
    return 0;
}
