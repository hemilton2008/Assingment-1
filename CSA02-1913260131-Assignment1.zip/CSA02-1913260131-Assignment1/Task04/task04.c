/* Task 04 - macro safety */
#include <stdio.h>

#define RUPEES_TO_PAISE(r)  ((r) * 100L)
#define BAD_SQUARE(x)       x * x
#define SQUARE(x)           ((x) * (x))
#define BAD_MAX(a, b)       a > b ? a : b
#define MAX(a, b)           (((a) > (b)) ? (a) : (b))

int main(void)
{
    int a = 4;
    printf("BAD_SQUARE(a+1) = %d   (expected 25)\n", BAD_SQUARE(a + 1));
    printf("SQUARE(a+1)     = %d\n", SQUARE(a + 1));

    int i = 7, j = 5;
    int m = MAX(i++, j);              /* i++ is evaluated twice */
    printf("MAX(i++, j) = %d, i is now %d (expected 7 and 8)\n", m, i);

    int x = 3, y = 7;
    int r = 10 + BAD_MAX(x, y);       /* precedence problem */
    printf("10 + BAD_MAX(3,7) = %d   (expected 17)\n", r);

    printf("RUPEES_TO_PAISE(162) = %ld\n", RUPEES_TO_PAISE(162));
    printf("RUPEES_TO_PAISE(1+1) = %ld  (parenthesised argument: 200)\n", RUPEES_TO_PAISE(1 + 1));
    return 0;
}
