/* Task 04 alternative: static inline functions instead of macros */
#include <stdio.h>
#include <time.h>
static inline int square_f(int x) { return x * x; }
static inline int max_f(int a, int b) { return a > b ? a : b; }
#define SQUARE(x) ((x) * (x))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define LOOPS 200000000L
int main(void)
{
    int i = 7, j = 5;
    int m = max_f(i++, j);
    printf("max_f(i++, j) = %d, i is now %d (one increment only)\n", m, i);
    printf("square_f(4+1) = %d\n", square_f(4 + 1));
    volatile long sink = 0; long s1 = 0, s2 = 0;
    clock_t t0 = clock();
    for (long k = 0; k < LOOPS; k++) s1 += SQUARE((int)(k & 1023)) + MAX((int)(k & 7), 3);
    double tm = (double)(clock() - t0) / CLOCKS_PER_SEC;
    t0 = clock();
    for (long k = 0; k < LOOPS; k++) s2 += square_f((int)(k & 1023)) + max_f((int)(k & 7), 3);
    double tf = (double)(clock() - t0) / CLOCKS_PER_SEC;
    sink = s1 + s2;
    printf("%ld iterations: macro %.3f s, inline function %.3f s, results equal: %s\n",
           LOOPS, tm, tf, s1 == s2 ? "yes" : "NO");
    (void)sink;
    return 0;
}
