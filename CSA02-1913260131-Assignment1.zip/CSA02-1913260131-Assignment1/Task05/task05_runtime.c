/* Task 05 alternative: run-time debug flag vs compile-time #ifdef */
#include <stdio.h>
#include <time.h>
#define LOOPS 300000000L
static int debug = 0;
static unsigned work(unsigned x)
{
#ifdef CT_DEBUG
    printf("x=%u\n", x);
#endif
    return x * 2654435761u + 1;
}
static unsigned work_rt(unsigned x)
{
    if (debug) printf("x=%u\n", x);
    return x * 2654435761u + 1;
}
int main(void)
{
    unsigned a = 1, b = 1;
    clock_t t0 = clock();
    for (long i = 0; i < LOOPS; i++) a = work(a);
    double t_ct = (double)(clock() - t0) / CLOCKS_PER_SEC;
    t0 = clock();
    for (long i = 0; i < LOOPS; i++) b = work_rt(b);
    double t_rt = (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("%ld calls: compile-time (debug off) %.3f s, run-time flag (debug off) %.3f s, same result: %s\n",
           LOOPS, t_ct, t_rt, a == b ? "yes" : "NO");
    return 0;
}
