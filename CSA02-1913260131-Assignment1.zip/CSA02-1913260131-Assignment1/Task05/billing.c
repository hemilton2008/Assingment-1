#include <stdio.h>
#include "tariff.h"
#include "tariff.h"       /* included twice on purpose: the guard prevents errors */

unsigned int consumption(meter_t previous, meter_t current)
{
    unsigned int u = (meter_t)(current - previous);
#ifdef DEBUG
    printf("[DEBUG] previous=%u current=%u units=%u\n", (unsigned)previous, (unsigned)current, u);
#endif
    return u;
}

long compute_bill(unsigned int units)
{
    long paise = FIXED_CHARGE_PAISE;
    unsigned int rest = units;
    if (rest > SLAB2_UNITS) { paise += (long)(rest - SLAB2_UNITS) * RATE3_PAISE; rest = SLAB2_UNITS; }
    if (rest > SLAB1_UNITS) { paise += (long)(rest - SLAB1_UNITS) * RATE2_PAISE; rest = SLAB1_UNITS; }
    paise += (long)rest * RATE1_PAISE;
#ifdef DEBUG
    printf("[DEBUG] units=%u bill=%ld paise\n", units, paise);
#endif
    return paise;
}
