#include <stdio.h>
#include "tariff.h"

int main(void)
{
    meter_t prev[] = {1200, 65400, 500};
    meter_t curr[] = {1530, 120, 650};
    for (int i = 0; i < 3; i++) {
        unsigned int u = consumption(prev[i], curr[i]);
        long p = compute_bill(u);
        printf("House %d: %u units -> Rs %ld.%02ld\n", i + 1, u, p / 100, p % 100);
    }
    return 0;
}
