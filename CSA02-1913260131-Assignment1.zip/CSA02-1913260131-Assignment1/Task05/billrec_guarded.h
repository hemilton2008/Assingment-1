#ifndef BILLREC_H
#define BILLREC_H
struct bill_record { unsigned house; long paise; };
#endif
