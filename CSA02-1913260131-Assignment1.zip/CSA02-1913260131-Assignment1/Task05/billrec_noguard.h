struct bill_record { unsigned house; long paise; };
