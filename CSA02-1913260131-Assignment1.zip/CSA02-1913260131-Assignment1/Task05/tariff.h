#ifndef TARIFF_H          /* include guard: header can be included many times */
#define TARIFF_H

#define SLAB1_UNITS        100        /* first 100 units            */
#define SLAB2_UNITS        200        /* units 101 to 200           */
#define RATE1_PAISE        0          /* first slab is free         */
#define RATE2_PAISE        225        /* Rs 2.25 per unit           */
#define RATE3_PAISE        450        /* Rs 4.50 per unit above 200 */
#define FIXED_CHARGE_PAISE 5000L      /* Rs 50 fixed charge         */
#define RUPEES_TO_PAISE(r) ((r) * 100L)

typedef unsigned short meter_t;       /* 16-bit meter register */

unsigned int consumption(meter_t previous, meter_t current);
long compute_bill(unsigned int units);

#endif /* TARIFF_H */
