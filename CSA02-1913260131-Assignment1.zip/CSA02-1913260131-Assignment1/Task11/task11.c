/* Task 11 alternative: tariff read from a configuration file at start-up */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    long slab1, slab2, rate1, rate2, rate3, fixed;
} tariff_t;

/* returns number of recognised keys read, or -1 if the file cannot be opened */
static int load_tariff(const char *path, tariff_t *t)
{
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    char key[64]; long val; int found = 0;
    while (fscanf(fp, "%63s %ld", key, &val) == 2) {
        if      (!strcmp(key, "SLAB1_UNITS"))        { t->slab1 = val; found++; }
        else if (!strcmp(key, "SLAB2_UNITS"))        { t->slab2 = val; found++; }
        else if (!strcmp(key, "RATE1_PAISE"))        { t->rate1 = val; found++; }
        else if (!strcmp(key, "RATE2_PAISE"))        { t->rate2 = val; found++; }
        else if (!strcmp(key, "RATE3_PAISE"))        { t->rate3 = val; found++; }
        else if (!strcmp(key, "FIXED_CHARGE_PAISE")) { t->fixed = val; found++; }
    }
    fclose(fp);
    return found;
}

static int tariff_valid(const tariff_t *t)
{
    return t->slab1 >= 0 && t->slab1 < t->slab2 &&
           t->rate1 >= 0 && t->rate2 >= 0 && t->rate3 >= 0 && t->fixed >= 0;
}

static long bill(const tariff_t *t, unsigned units)
{
    long p = t->fixed; long rest = units;
    if (rest > t->slab2) { p += (rest - t->slab2) * t->rate3; rest = t->slab2; }
    if (rest > t->slab1) { p += (rest - t->slab1) * t->rate2; rest = t->slab1; }
    return p + rest * t->rate1;
}

int main(int argc, char **argv)
{
    const char *path = argc > 1 ? argv[1] : "tariff.cfg";
    tariff_t t = {0};
    clock_t t0 = clock();
    int n = load_tariff(path, &t);
    double dt = (double)(clock() - t0) / CLOCKS_PER_SEC;
    if (n != 6 || !tariff_valid(&t)) { printf("tariff file '%s' missing or invalid (keys read: %d)\n", path, n); return 1; }
    printf("tariff loaded from %s (%d keys, %.6f s, struct = %zu bytes)\n", path, n, dt, sizeof t);
    int tests[] = {0, 100, 150, 200, 350};
    for (int i = 0; i < 5; i++) { long p = bill(&t, tests[i]); printf("%3d units -> Rs %ld.%02ld\n", tests[i], p / 100, p % 100); }
    return 0;
}
