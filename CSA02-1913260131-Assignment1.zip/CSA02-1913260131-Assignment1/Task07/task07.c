/* Task 07 - type conversion surprises */
#include <stdio.h>
#include <math.h>

int main(void)
{
    /* 1. integer division */
    int units = 150;
    printf("1) units / 100            = %d   (150/100 as integers, fraction lost)\n", units / 100);
    printf("   units / 100.0          = %.2f\n", units / 100.0);
    long total_paise = 16250; int n = 4;
    printf("   average of 16250 paise over 4 bills = %ld (integer), %.2f (double)\n",
           total_paise / n, (double)total_paise / n);

    /* 2. casting a large long to int */
    long big = 5000000000L;
    printf("2) (int)5000000000L       = %d   (high bits discarded)\n", (int)big);

    /* 3. signed/unsigned comparison */
    int minus = -1; unsigned int one = 1;
    printf("3) (-1 < 1u)              = %d   (-1 converted to 4294967295u)\n", minus < one);

    /* 4. integer promotion of 16-bit values */
    unsigned short r = 65535;
    printf("4) r + 1 (r=65535 ushort) = %d   (promoted to int, no wrap)\n", r + 1);
    printf("   (unsigned short)(r+1)  = %u   (wrap happens only after the cast)\n", (unsigned short)(r + 1));

    /* 5. float cannot hold every integer */
    float f = 16777217;
    printf("5) (float)16777217        = %.0f  (24-bit mantissa)\n", f);

    /* 6. rounding to paise */
    double rupees = 1.005;
    printf("6) 1.005 rupees -> paise: truncate %ld, naive round %ld, round(x*100) %.0f\n",
           (long)(rupees * 100), (long)(rupees * 100 + 0.5), round(rupees * 100));
    printf("   (1.005 is stored as %.20f)\n", rupees);

    /* the rule used in the project: round half up, in integers only */
    long num = 2125, den = 10;         /* e.g. 212.5 paise */
    long rounded = (num + den / 2) / den;
    printf("   integer rule (num+den/2)/den: 2125/10 -> %ld paise\n", rounded);
    return 0;
}
