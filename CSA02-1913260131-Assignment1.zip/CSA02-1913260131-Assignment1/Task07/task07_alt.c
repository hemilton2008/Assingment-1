/* Task 07 alternative: float/double sums rounded once at the end vs integer paise */
#include <stdio.h>
#include <math.h>
#include <time.h>
int main(void)
{
    long ns[] = {4000, 60000, 800000};
    printf("%8s | %14s %12s %10s | %14s %12s %10s\n", "n", "float total", "error", "wrong?", "double total", "error", "wrong?");
    for (int k = 0; k < 3; k++) {
        float f = 0; double d = 0; long p = 0;
        for (long i = 0; i < ns[k]; i++) {
            long bill = 16237 + (i % 97);               /* varying bills, in paise */
            p += bill; f += bill / 100.0f; d += bill / 100.0;
        }
        double exact = p / 100.0;
        double rf = roundf(f * 100.0f) / 100.0, rd = round(d * 100.0) / 100.0;
        printf("%8ld | %14.2f %12.4f %10s | %14.2f %12.6f %10s\n", ns[k],
               rf, fabs((double)f - exact), rf == exact ? "no" : "YES",
               rd, fabs(d - exact), rd == exact ? "no" : "YES");
    }
    printf("sizeof(float)=%zu sizeof(double)=%zu sizeof(long)=%zu\n", sizeof(float), sizeof(double), sizeof(long));
    /* time per addition */
    const long N = 400000000L;
    volatile float vf = 0; volatile double vd = 0; volatile long vl = 0;
    clock_t t0 = clock(); for (long i = 0; i < N; i++) vf = vf + 0.01f; double tf = (double)(clock()-t0)/CLOCKS_PER_SEC;
    t0 = clock(); for (long i = 0; i < N; i++) vd = vd + 0.01; double td = (double)(clock()-t0)/CLOCKS_PER_SEC;
    t0 = clock(); for (long i = 0; i < N; i++) vl = vl + 1; double tl = (double)(clock()-t0)/CLOCKS_PER_SEC;
    printf("%ld additions: float %.3f s, double %.3f s, long %.3f s\n", N, tf, td, tl);
    return 0;
}
