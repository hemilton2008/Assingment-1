/* Task 09 alternative: slabs in arrays + loop, compared with the if-version */
#include <stdio.h>
#include <time.h>
#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE1_PAISE 0
#define RATE2_PAISE 225
#define RATE3_PAISE 450
#define SLABS 3
static const unsigned int limit[SLABS] = {SLAB1_UNITS, SLAB2_UNITS, 0xFFFFFFFFu}; /* upper bound of each slab */
static const long rate[SLABS] = {RATE1_PAISE, RATE2_PAISE, RATE3_PAISE};

static long energy_if(unsigned int units)
{
    long p = 0; unsigned int rest = units;
    if (rest > SLAB2_UNITS) { p += (long)(rest - SLAB2_UNITS) * RATE3_PAISE; rest = SLAB2_UNITS; }
    if (rest > SLAB1_UNITS) { p += (long)(rest - SLAB1_UNITS) * RATE2_PAISE; rest = SLAB1_UNITS; }
    return p + (long)rest * RATE1_PAISE;
}
static long energy_loop(unsigned int units)
{
    long p = 0; unsigned int lower = 0;
    for (int s = 0; s < SLABS && units > lower; s++) {
        unsigned int upper = limit[s];
        unsigned int in_slab = (units < upper ? units : upper) - lower;
        p += (long)in_slab * rate[s];
        lower = upper;
    }
    return p;
}
int main(void)
{
    long mismatches = 0;
    for (unsigned int u = 0; u <= 65535u; u++) if (energy_if(u) != energy_loop(u)) mismatches++;
    printf("exhaustive check of units 0..65535: mismatches = %ld\n", mismatches);
    const long N = 100000000L; volatile long sink = 0;
    clock_t t0 = clock();
    for (long i = 0; i < N; i++) sink += energy_if((unsigned)(i & 1023));
    double a = (double)(clock() - t0) / CLOCKS_PER_SEC;
    t0 = clock();
    for (long i = 0; i < N; i++) sink += energy_loop((unsigned)(i & 1023));
    double b = (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("%ld bills: if-version %.3f s (%.1f ns/bill), loop-version %.3f s (%.1f ns/bill)\n",
           N, a, a / N * 1e9, b, b / N * 1e9);
    printf("extra space: 2 arrays of %d entries = %zu bytes\n", SLABS, sizeof limit + sizeof rate);
    return 0;
}
